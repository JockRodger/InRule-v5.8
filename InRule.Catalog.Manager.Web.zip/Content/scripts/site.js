﻿$(function () {
    $('div[data-toggle="popover"]').popover({
        delay: { "show": 150, "hide": 50 },
        trigger: "hover"
    });
});