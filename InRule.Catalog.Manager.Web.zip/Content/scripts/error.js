﻿var hasWarningBeenShown = false;

function onFailure() {
    $('#submit-feedback-form').waitable('reset');
    $('#submit-feedback-error').removeClass('hidden');
}

function onBegin() {
    $('#submit-feedback-error').addClass('hidden');

    if (hasWarningBeenShown) {
        return true;
    }

    var emailAddressTextbox = $('#EmailAddress');
    if (emailAddressTextbox.val().length <= 0) {
        $('#email-warning-modal-message').removeClass('hidden');
    }
    var descriptionTextarea = $('#Description');
    if (descriptionTextarea.val().length <= 0) {
        $('#description-warning-modal-message').removeClass('hidden');
    }

    if (emailAddressTextbox.val().length <= 0 || descriptionTextarea.val().length <= 0) {
        hasWarningBeenShown = true;
        showWarningModal();

        $('#submit-feedback-form').waitable('reset');
        return false;
    }

    return true;
}

function showWarningModal() {
    $('#warning-modal').modal('show');
}

